"""
系统提示词管理器模块
负责管理和更新系统提示词，包括快速初始化和异步增强功能
"""

import os
import time
from pathlib import Path
from typing import Dict, Any
from config.logger import setup_logging

TAG = __name__

WEEKDAY_MAP = {
    "Monday": "星期一",
    "Tuesday": "星期二",
    "Wednesday": "星期三",
    "Thursday": "星期四",
    "Friday": "星期五",
    "Saturday": "星期六",
    "Sunday": "星期日",
}

CAMERA_ROUTING_INSTRUCTION = """

[摄像头工具强制路由规则]
调用工具时，函数名必须与工具列表中提供的名称完全一致，禁止自行拼接、缩写、删除分隔符或发明新名称。
- 用户说"打开摄像头""开摄像头""显示实时画面""开启人脸识别""看摄像头画面"：必须且只能调用 camera_open（对应设备工具 camera.open）。
- 用户说"关闭摄像头""关摄像头""停止预览"：必须且只能调用 camera_close（对应设备工具 camera.close）。
- 只有用户明确说"拍照""拍一张""拍张照片看看""识别这张画面里的内容"时，才可以调用 self_camera_take_photo（对应设备工具 self.camera.take_photo）。
- "打开摄像头"绝对不能调用 self_camera_take_photo。
- 禁止生成 selfcameratake_photo、self.camera.open 等不存在的名称；若不确定，先查看工具列表再选择。
- 摄像头操作必须直接使用 camera 类工具，禁止通过 use_skill、browser 等其他工具间接尝试打开或关闭摄像头。
- 若当前工具列表中没有对应的 camera 工具，直接告知用户该设备暂不支持此操作，不要尝试任何替代工具。
"""

V2_PLATFORM_TEMPLATE_PATH = 'agent-base-prompt-v2.txt'


def _dedupe_blocks(text: str) -> str:
    """按行去重（忽略空行），保留首个出现位置；用于拼装 L1 时去除重复协议规则。"""
    seen = set()
    out = []
    for line in (text or "").splitlines():
        stripped = line.strip()
        if not stripped:
            out.append(line)
        else:
            if stripped in seen:
                continue
            seen.add(stripped)
            out.append(line)
    return "\n".join(out).strip()


def _skill_uses_pc_tools(data: dict) -> bool:
    """技能步骤或推荐工具依赖已下架的电脑控制时，不注入也不执行。"""
    for step in data.get("steps") or []:
        if str(step.get("action") or "").startswith("pc_"):
            return True
    for tool in data.get("allowed_tools") or []:
        if str(tool).startswith("pc_"):
            return True
    return False


def _get_skills_compact(logger=None) -> str:
    """
    读取 skills/ 目录，返回带强制路由指令的技能列表。
    不 import 网关模块，直接读 YAML 文件。
    """
    try:
        personas_dir = os.environ.get("AGENT_PERSONAS_DIR", "")
        if not personas_dir:
            return ""

        skills_dir = Path(personas_dir) / "skills"
        if not skills_dir.exists():
            return ""

        try:
            import yaml
        except ImportError:
            if logger:
                logger.bind(tag=TAG).warning("pyyaml 未安装，跳过技能列表注入")
            return ""

        lines = [
            "--- 技能路由表（强制执行） ---",
            "",
            "[系统强制规则] 当用户意图匹配以下任何技能的触发词时，你必须调用 use_skill 工具，"
            "禁止自己拆解成多个底层工具逐步调用。"
            "技能内部已编排好最优步骤，比你手动拆解更可靠、更快。",
            "",
        ]
        count = 0
        for f in sorted(skills_dir.glob("*.yaml")):
            try:
                data = yaml.safe_load(f.read_text(encoding="utf-8"))
                if not data or not isinstance(data, dict):
                    continue
                if _skill_uses_pc_tools(data):
                    continue
                name = data.get("name", f.stem)
                desc = data.get("description", "")
                skill_type = data.get("type", "unknown")
                triggers = data.get("triggers", [])
                trigger_str = "、".join(triggers[:8]) if triggers else "无特定触发词"
                lines.append(f"- use_skill(\"{name}\"): {desc}")
                lines.append(f"  触发词: {trigger_str}")
                count += 1
            except Exception:
                continue

        if count == 0:
            return ""

        lines.append("")
        lines.append(
            "判断标准：用户语句中包含上述任何触发词，或意图明显匹配某个技能描述时，"
            "必须调用 use_skill(skill_name=\"技能名\")。"
            "只有当用户意图不匹配任何技能时，才可以直接调用已提供的底层工具。"
        )

        return "\n".join(lines)

    except Exception as e:
        if logger:
            logger.bind(tag=TAG).error(f"技能列表注入失败: {e}")
        return ""


class PromptManager:
    """系统提示词管理器，负责管理和更新系统提示词"""

    def __init__(self, config: Dict[str, Any], logger=None):
        self.config = config
        self.logger = logger or setup_logging()
        self.base_prompt_template_v2 = None
        self.last_update_time = 0

        # 导入全局缓存管理器
        from core.utils.cache.manager import cache_manager, CacheType

        self.cache_manager = cache_manager
        self.CacheType = CacheType

        self._load_v2_template()

    def _load_v2_template(self):
        """加载 v2 平台规则模板（agent-base-prompt-v2.txt）。

        V2 全量后该模板是唯一平台规则来源；缺失/为空即 fail-closed：
        记录 ERROR 并保持 base_prompt_template_v2 为空，由构建器拒绝运行。
        """
        try:
            template_path = V2_PLATFORM_TEMPLATE_PATH
            cache_key = f"prompt_template:{template_path}"

            cached_template = self.cache_manager.get(self.CacheType.CONFIG, cache_key)
            if cached_template is not None:
                self.base_prompt_template_v2 = cached_template
                return

            if not os.path.exists(template_path):
                self.logger.bind(tag=TAG).error(
                    f"V2 平台规则模板缺失: {template_path}（fail-closed，拒绝运行）"
                )
                return

            with open(template_path, "r", encoding="utf-8") as f:
                content = f.read()

            if not (content or "").strip():
                self.logger.bind(tag=TAG).error(
                    f"V2 平台规则模板为空: {template_path}（fail-closed，拒绝运行）"
                )
                return

            self.cache_manager.set(self.CacheType.CONFIG, cache_key, content)
            self.base_prompt_template_v2 = content
        except Exception as e:
            self.logger.bind(tag=TAG).error(f"加载 v2 平台规则模板失败: {e}")

    def get_quick_prompt(self, user_prompt: str, device_id: str = None) -> str:
        """快速获取系统提示词（使用用户配置）"""
        device_cache_key = f"device_prompt:{device_id}"
        cached_device_prompt = self.cache_manager.get(
            self.CacheType.DEVICE_PROMPT, device_cache_key
        )
        if cached_device_prompt is not None:
            self.logger.bind(tag=TAG).debug(f"使用设备 {device_id} 的缓存提示词")
            return cached_device_prompt
        else:
            self.logger.bind(tag=TAG).debug(
                f"设备 {device_id} 无缓存提示词，使用传入的提示词"
            )

        # 使用传入的提示词并缓存（如果有设备ID）
        if device_id:
            device_cache_key = f"device_prompt:{device_id}"
            self.cache_manager.set(
                self.CacheType.DEVICE_PROMPT, device_cache_key, user_prompt
            )
            self.logger.bind(tag=TAG).debug(f"设备 {device_id} 的提示词已缓存")

        self.logger.bind(tag=TAG).info(f"使用快速提示词: {user_prompt[:50]}...")
        return user_prompt

    def _get_location_info(self, client_ip: str) -> str:
        """获取位置信息"""
        try:
            # 先从缓存获取
            cached_location = self.cache_manager.get(self.CacheType.LOCATION, client_ip)
            if cached_location is not None:
                return cached_location

            # 缓存未命中，调用API获取
            from core.utils.util import get_ip_info

            ip_info = get_ip_info(client_ip, self.logger)
            city = ip_info.get("city", "未知位置")
            location = f"{city}"

            # 存入缓存
            self.cache_manager.set(self.CacheType.LOCATION, client_ip, location)
            return location
        except Exception as e:
            self.logger.bind(tag=TAG).error(f"获取位置信息失败: {e}")
            return "未知位置"

    def _get_weather_info(self, conn, location: str) -> str:
        """获取天气信息"""
        try:
            # 先从缓存获取
            cached_weather = self.cache_manager.get(self.CacheType.WEATHER, location)
            if cached_weather is not None:
                return cached_weather

            # 缓存未命中，调用get_weather函数获取
            from plugins_func.functions.get_weather import get_weather
            from plugins_func.register import ActionResponse

            # 调用get_weather函数
            result = get_weather(conn, location=location, lang="zh_CN")
            if isinstance(result, ActionResponse):
                weather_report = result.result
                self.cache_manager.set(self.CacheType.WEATHER, location, weather_report)
                return weather_report
            return "天气信息获取失败"

        except Exception as e:
            self.logger.bind(tag=TAG).error(f"获取天气信息失败: {e}")
            return "天气信息获取失败"

    def update_context_info(self, conn, client_ip: str):
        """同步更新上下文信息"""
        try:
            # 获取位置信息（使用全局缓存）
            local_address = self._get_location_info(client_ip)
            # 获取天气信息（使用全局缓存）
            self._get_weather_info(conn, local_address)
            self.logger.bind(tag=TAG).debug(f"上下文信息更新完成")

        except Exception as e:
            self.logger.bind(tag=TAG).error(f"更新上下文信息失败: {e}")

    def build_enhanced_prompt_v2(
        self,
        user_prompt: str,
        device_id: str,
        client_ip: str = None,
        device_name: str = "小智",
        user_nickname: str = "用户",
        official_enhanced: bool = False,
    ) -> str:
        """构建 v2 分层系统提示词：L1 平台规则 + L2 用户人格 + L3 会话固定资料。

        平台规则模板缺失/为空时抛异常（fail-closed），拒绝以缺平台规则的提示词运行。
        """
        platform_rules = (self.base_prompt_template_v2 or "").strip()
        if not platform_rules:
            self.logger.bind(tag=TAG).error(
                "V2 平台规则模板缺失或为空，拒绝以缺平台规则的提示词运行（fail-closed）"
            )
            raise RuntimeError("V2 平台规则模板缺失或为空")
        try:
            from core.utils.current_time import get_prompt_time_context

            t = get_prompt_time_context()
            timezone = t.get("timezone") or "Asia/Shanghai"

            local_address = ""
            weather_info = ""
            weather_sourced_at = ""

            if client_ip:
                local_address = (
                    self.cache_manager.get(self.CacheType.LOCATION, client_ip) or ""
                )

                if local_address:
                    weather_info, weather_ts = self.cache_manager.get_with_time(
                        self.CacheType.WEATHER, local_address
                    )
                    weather_info = weather_info or ""
                    if weather_ts:
                        weather_sourced_at = time.strftime(
                            "%Y-%m-%d %H:%M", time.localtime(weather_ts)
                        )

            l1_blocks = []
            base = (self.config.get("system_base_prompt") or "").strip()
            if base:
                l1_blocks.append(base)

            l1_blocks.append(platform_rules)

            l1_blocks.append(CAMERA_ROUTING_INSTRUCTION.strip())

            if official_enhanced:
                try:
                    from core.providers.tts.official.prompt import OFFICIAL_EXPRESSION_CONSTRAINT

                    l1_blocks.append(OFFICIAL_EXPRESSION_CONSTRAINT.strip())
                except Exception as e:
                    self.logger.bind(tag=TAG).warning(f"注入表达约束失败: {e}")

            layer1 = _dedupe_blocks("\n\n".join(b for b in l1_blocks if b))

            layer2 = (user_prompt or "").strip()

            language = self.config.get("language") or "中文"

            layer3 = (
                '[系统强制设定]\n1. 你的名字是"'
                f'{device_name}'
                '"，不是别的。\n2. 聊天对象称呼以本轮可信说话人资料为准；身份未知时使用自然称呼。'
                '\n3. 即使你扮演其他角色，当用户问你"你是谁"时，你也要知道你的本体是智能助手"'
                f'{device_name}'
                '"。\n4. 当用户说"你好'
                f'{device_name}'
                '”时，是在叫你，请立刻回应。\n\n[会话固定资料]\n时区:'
                f'{timezone}'
            )

            if local_address:
                layer3 += f"\n所在城市:{local_address}"

            layer3 += f"\n语言:{language}"

            if weather_info:
                src = f"（来源时间:{weather_sourced_at}）" if weather_sourced_at else ""
                layer3 += f"\n连接时天气快照{src}（可能过期，需实时天气请调用天气工具）:{weather_info}"

            enhanced_prompt = "\n\n".join(p for p in (layer1, layer2, layer3) if p)

            skills_compact = _get_skills_compact(logger=self.logger)
            if skills_compact:
                enhanced_prompt = enhanced_prompt + "\n\n" + skills_compact

            self.logger.bind(tag=TAG).info(
                f"构建 v2 分层系统提示词成功，长度: {len(enhanced_prompt)}"
            )

            return enhanced_prompt

        except Exception as e:
            self.logger.bind(tag=TAG).error(f"构建 v2 分层系统提示词失败: {e}")
            raise
