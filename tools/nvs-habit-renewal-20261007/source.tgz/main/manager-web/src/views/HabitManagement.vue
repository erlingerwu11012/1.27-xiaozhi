<template>
    <div class="habit-management">
        <HeaderBar />

        <div class="operation-bar">
            <h2 class="page-title">{{ $t('habitManagement.pageTitle') }}</h2>
            <el-button type="primary" class="btn-add" @click="openCreateDialog">
                + {{ $t('habitManagement.addHabit') }}
            </el-button>
        </div>

        <div class="main-wrapper">
            <div class="content-panel">
                <div class="content-area">
                    <!-- 习惯列表 -->
                    <el-table
                        :data="habitList"
                        v-loading="loading"
                        style="width: 100%"
                        empty-text="暂无手动习惯，点击右上角「+ 添加习惯」创建"
                    >
                        <el-table-column
                            prop="description"
                            :label="$t('habitManagement.col.description')"
                            min-width="140"
                        />
                        <el-table-column
                            :label="$t('habitManagement.col.triggerTime')"
                            width="120"
                        >
                            <template slot-scope="{ row }">
                                {{ formatTime(row.hour, row.minute) }}
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="advanceMinutes"
                            :label="$t('habitManagement.col.advanceMinutes')"
                            width="130"
                        >
                            <template slot-scope="{ row }">
                                {{ row.advanceMinutes }} {{ $t('habitManagement.minutesBefore') }}
                            </template>
                        </el-table-column>
                        <el-table-column
                            :label="$t('habitManagement.col.source')"
                            width="100"
                        >
                            <template slot-scope="{ row }">
                                <el-tag
                                    :type="row.source === 'manual' ? 'primary' : 'info'"
                                    size="small"
                                >
                                    {{ row.source === 'manual'
                                        ? $t('habitManagement.sourceManual')
                                        : $t('habitManagement.sourceAuto') }}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            :label="$t('habitManagement.col.synced')"
                            width="100"
                        >
                            <template slot-scope="{ row }">
                                <el-tag
                                    :type="row.synced === 1 ? 'success' : 'warning'"
                                    size="small"
                                >
                                    {{ row.synced === 1
                                        ? $t('habitManagement.syncedYes')
                                        : $t('habitManagement.syncedNo') }}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="createdAt"
                            :label="$t('habitManagement.col.createdAt')"
                            width="160"
                        />
                        <el-table-column
                            :label="$t('habitManagement.col.actions')"
                            width="100"
                            fixed="right"
                        >
                            <template slot-scope="{ row }">
                                <el-button
                                    type="danger"
                                    size="mini"
                                    @click="handleDelete(row)"
                                >
                                    {{ $t('habitManagement.delete') }}
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </div>
        </div>

        <!-- 创建习惯对话框 -->
        <el-dialog
            :title="$t('habitManagement.createTitle')"
            :visible.sync="dialogVisible"
            width="480px"
            @close="resetForm"
        >
            <el-form
                ref="createForm"
                :model="form"
                :rules="rules"
                label-width="120px"
            >
                <el-form-item
                    :label="$t('habitManagement.form.description')"
                    prop="description"
                >
                    <el-input
                        v-model="form.description"
                        :placeholder="$t('habitManagement.form.descriptionPlaceholder')"
                        maxlength="50"
                        show-word-limit
                    />
                </el-form-item>

                <el-form-item
                    :label="$t('habitManagement.form.triggerTime')"
                    prop="hour"
                >
                    <el-time-picker
                        v-model="form.timeValue"
                        format="HH:mm"
                        value-format="HH:mm"
                        :placeholder="$t('habitManagement.form.timePlaceholder')"
                        style="width: 100%"
                        @change="onTimeChange"
                    />
                </el-form-item>

                <el-form-item
                    :label="$t('habitManagement.form.advanceMinutes')"
                    prop="advanceMinutes"
                >
                    <el-input-number
                        v-model="form.advanceMinutes"
                        :min="0"
                        :max="60"
                        :step="1"
                        style="width: 100%"
                    />
                    <span class="form-tip">{{ $t('habitManagement.form.advanceTip') }}</span>
                </el-form-item>

                <el-form-item :label="$t('habitManagement.form.deviceId')">
                    <el-input
                        v-model="form.deviceId"
                        :placeholder="$t('habitManagement.form.deviceIdPlaceholder')"
                    />
                </el-form-item>
            </el-form>

            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">
                    {{ $t('habitManagement.cancel') }}
                </el-button>
                <el-button
                    type="primary"
                    :loading="saving"
                    @click="handleCreate"
                >
                    {{ $t('habitManagement.confirm') }}
                </el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
import HeaderBar from "@/components/HeaderBar.vue";
import Api from "@/apis/api";

export default {
    name: "HabitManagement",
    components: { HeaderBar },
    data() {
        return {
            loading: false,
            saving: false,
            dialogVisible: false,
            habitList: [],
            form: {
                description: "",
                timeValue: null,
                hour: 8,
                minute: 0,
                advanceMinutes: 2,
                deviceId: "",
            },
        };
    },
    computed: {
        rules() {
            return {
                description: [
                    { required: true, message: this.$t("habitManagement.form.descriptionRequired"), trigger: "blur" },
                    { min: 1, max: 50, message: this.$t("habitManagement.form.descriptionLength"), trigger: "blur" },
                ],
                hour: [
                    { required: true, message: this.$t("habitManagement.form.timeRequired"), trigger: "change" },
                ],
                advanceMinutes: [
                    { required: true, message: this.$t("habitManagement.form.advanceRequired"), trigger: "blur" },
                ],
            };
        },
    },
    mounted() {
        this.loadHabits();
    },
    methods: {
        loadHabits() {
            this.loading = true;
            Api.habit.listHabits({ enabledOnly: false }, (res) => {
                this.loading = false;
                if (res && res.code === 0 && res.data) {
                    this.habitList = res.data;
                } else {
                    this.$message.error(this.$t("habitManagement.loadFail"));
                }
            });
        },

        openCreateDialog() {
            this.dialogVisible = true;
        },

        resetForm() {
            this.form = {
                description: "",
                timeValue: null,
                hour: 8,
                minute: 0,
                advanceMinutes: 2,
                deviceId: "",
            };
            if (this.$refs.createForm) {
                this.$refs.createForm.clearValidate();
            }
        },

        onTimeChange(val) {
            if (val) {
                const parts = val.split(":");
                this.form.hour = parseInt(parts[0], 10);
                this.form.minute = parseInt(parts[1], 10);
            }
        },

        handleCreate() {
            this.$refs.createForm.validate((valid) => {
                if (!valid) return;
                if (!this.form.timeValue) {
                    this.$message.warning(this.$t("habitManagement.form.timeRequired"));
                    return;
                }
                this.saving = true;
                const payload = {
                    description: this.form.description.trim(),
                    hour: this.form.hour,
                    minute: this.form.minute,
                    advanceMinutes: this.form.advanceMinutes,
                    deviceId: this.form.deviceId.trim() || null,
                };
                Api.habit.createHabit(payload, (res) => {
                    this.saving = false;
                    if (res && res.code === 0) {
                        this.$message.success(this.$t("habitManagement.createSuccess"));
                        this.dialogVisible = false;
                        this.loadHabits();
                    } else {
                        this.$message.error(res.msg || this.$t("habitManagement.createFail"));
                    }
                });
            });
        },

        handleDelete(row) {
            this.$confirm(
                this.$t("habitManagement.deleteConfirm", { name: row.description }),
                this.$t("habitManagement.deleteTitle"),
                {
                    confirmButtonText: this.$t("habitManagement.confirmDelete"),
                    cancelButtonText: this.$t("habitManagement.cancel"),
                    type: "warning",
                }
            ).then(() => {
                Api.habit.deleteHabit(row.id, (res) => {
                    if (res && res.code === 0) {
                        this.$message.success(this.$t("habitManagement.deleteSuccess"));
                        this.loadHabits();
                    } else {
                        this.$message.error(res.msg || this.$t("habitManagement.deleteFail"));
                    }
                });
            }).catch(() => {});
        },

        formatTime(hour, minute) {
            return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
        },
    },
};
</script>

<style scoped>
.habit-management {
    min-height: 100vh;
    background: #f5f7fb;
}

.operation-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 32px 0;
}

.page-title {
    font-size: 20px;
    font-weight: 600;
    color: #1a1a2e;
    margin: 0;
}

.btn-add {
    background: #4f6ef6;
    border-color: #4f6ef6;
    border-radius: 8px;
}

.btn-add:hover {
    background: #3a5bd9;
    border-color: #3a5bd9;
}

.main-wrapper {
    padding: 24px 32px;
}

.content-panel {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
    overflow: hidden;
}

.content-area {
    padding: 24px;
}

.form-tip {
    margin-left: 8px;
    color: #909399;
    font-size: 12px;
}
</style>
