"""Finish an already authorized relative-setting plan using its fresh read."""
from .models import Step


def complete_relative_plan(decision, adjustments, tools):
    if (decision.mode not in {'operate', 'continue'} or decision.intent != 'action'
            or len(decision.steps) != 1 or len(adjustments) != 1):
        return decision
    read = decision.steps[0]
    if read.tool != 'self_get_device_status' or read.arguments or read.depends_on:
        return decision
    tool, delta = next(iter(adjustments.items()))
    if (tool not in {'self_audio_speaker_set_volume', 'self_screen_set_brightness'}
            or tool not in tools or set(decision.authorized_writes) != {tool}):
        return decision
    # This is not an authorization shortcut: both the original read and appended
    # setting still pass normal evidence, schema, session, ledger and receipt gates.
    name = 'apply_relative' if read.id != 'apply_relative' else 'apply_relative_2'
    decision.steps.append(Step(id=name, tool=tool, arguments={}, relative=delta, depends_on=[read.id]))
    decision.finished = True
    return decision
