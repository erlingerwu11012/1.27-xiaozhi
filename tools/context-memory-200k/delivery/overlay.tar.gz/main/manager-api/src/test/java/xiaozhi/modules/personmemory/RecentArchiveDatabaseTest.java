package xiaozhi.modules.personmemory;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import xiaozhi.modules.agent.dto.AgentChatHistoryReportDTO;
import xiaozhi.modules.agent.entity.AgentEntity;

@EnabledIfEnvironmentVariable(named="PERSON_MEMORY_TEST_DATABASE",matches="bailian_memory_test_[a-zA-Z0-9_]+")
class RecentArchiveDatabaseTest extends PersonMemoryDatabaseTest {
    RecentArchiveService recent;
    @BeforeEach void archiveSetup() {
        jdbc.update("DELETE FROM ai_agent_chat_history");jdbc.update("DELETE FROM ai_agent_chat_audio");
        recent=new RecentArchiveService(jdbc,memory,identities);
    }
    void archive(PersonTurnDTO actor,String event,String content,int type) {
        jdbc.update("INSERT INTO ai_agent_chat_history(account_id,person_id,agent_id,mac_address,session_id,chat_type,content,event_id,turn_id,directory_version,default_generation,recall_allowed,identity_status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,TRUE,?,NOW())",actor.getAccountId(),actor.getPersonId(),actor.getAgentId(),actor.getDeviceId(),"session",type,content,event,actor.getTurnId(),actor.getDirectoryVersion(),actor.getGeneration(),actor.getStatus());
    }
    @Test void recentIsPersonAgentGenerationTimeScopedAndNeverCallsCloud() {
        transaction.executeWithoutResult(tx->{
            var state=identities.snapshot(99001L);var actor=actor(state,(String)state.get("default_user_id"),"default",1);
            archive(actor,"new","我喜欢青苹果。",1);archive(actor,"reply","记住了青苹果",2);
            jdbc.update("INSERT INTO ai_agent_chat_history(account_id,person_id,agent_id,session_id,chat_type,content,default_generation,recall_allowed,created_at) VALUES(99002,?,'agent_other','s',1,'红苹果',1,TRUE,NOW()),(99001,?,'agent_other','s',1,'黄苹果',1,TRUE,NOW()),(99001,?,'agent_test','s',1,'旧苹果',2,TRUE,NOW()),(99001,?,'agent_test','s',1,'前天苹果',1,TRUE,DATE_SUB(NOW(),INTERVAL 2 DAY))",actor.getPersonId(),actor.getPersonId(),actor.getPersonId(),actor.getPersonId());
            String result=(String)recent.search(actor,"苹果").get("text");
            assertTrue(result.contains("青苹果"));assertFalse(result.contains("红苹果"));assertFalse(result.contains("黄苹果"));assertFalse(result.contains("旧苹果"));assertFalse(result.contains("前天苹果"));
            verify(gateway,never()).request(anyLong(),anyString(),anyLong(),anyString(),anyString(),any(),any(),any());
        });
    }
    @Test void correctionInvalidatesOldArchiveAndLateDefaultReportCannotRevive() {
        transaction.executeWithoutResult(tx->{
            var state=identities.snapshot(99001L);var actor=actor(state,(String)state.get("default_user_id"),"default",1);
            archive(actor,"old","我喜欢咖啡",1);memory.override(actor,"correct","咖啡","我现在喜欢茶");
            assertFalse((Boolean)recent.search(actor,"咖啡").get("reliable"));
            identities.retire(99001L,actor.getPersonId(),1,2);
            var report=new AgentChatHistoryReportDTO();report.setIdentity(actor);report.setMacAddress(actor.getDeviceId());
            var agent=new AgentEntity();agent.setId("agent_test");agent.setUserId(99001L);
            assertThrows(RuntimeException.class,()->recent.validateReport(report,agent));
            assertEquals(0,jdbc.queryForObject("SELECT COUNT(*) FROM ai_agent_chat_history WHERE person_id=?",Integer.class,actor.getPersonId()));
        });
    }
    @Test void eventPhysicalUniquenessAndUnknownNullability() {
        transaction.executeWithoutResult(tx->{
            var state=identities.snapshot(99001L);var actor=actor(state,(String)state.get("default_user_id"),"default",1);
            archive(actor,"event","苹果",1);assertTrue(recent.duplicate(99001L,"event"));
            assertThrows(RuntimeException.class,()->archive(actor,"event","duplicate",1));
            jdbc.update("INSERT INTO ai_agent_chat_history(account_id,person_id,agent_id,session_id,chat_type,content,identity_status,recall_allowed) VALUES(99001,NULL,'agent_test','unknown',1,'儿子的录入素材','unknown',FALSE)");
            assertEquals(1,jdbc.queryForObject("SELECT COUNT(*) FROM ai_agent_chat_history WHERE person_id IS NULL",Integer.class));
        });
    }
    @Test void shortForgetIsLocalAndNewFactsRemainRetrievable() {
        transaction.executeWithoutResult(tx->{
            jdbc.update("UPDATE ai_agent SET mem_model_id='Memory_mem_local_short' WHERE id='agent_test'");
            var state=identities.snapshot(99001L);var actor=actor(state,(String)state.get("default_user_id"),"default",1);
            archive(actor,"old","旧苹果",1);memory.override(actor,"forget","*",null);
            assertFalse((Boolean)recent.search(actor,"苹果").get("reliable"));
            assertEquals("local_only",jdbc.queryForObject("SELECT state FROM ai_memory_override",String.class));
            assertEquals(0,jdbc.queryForObject("SELECT COUNT(*) FROM ai_person_memory_entity",Integer.class));
            actor.setCapturedAt(System.currentTimeMillis()+3000);assertTrue(recent.recallAllowed(actor));
            actor.setCapturedAt(1L);assertFalse(recent.recallAllowed(actor));
            archive(actor,"new","新的青苹果",1);assertTrue((Boolean)recent.search(actor,"苹果").get("reliable"));
            verify(gateway,never()).request(anyLong(),anyString(),anyLong(),anyString(),anyString(),any(),any(),any());
        });
    }
    @Test void businessRecallRequiresOriginalAgentArchiveAndPreservesRealOutcome() {
        transaction.executeWithoutResult(tx->{
            var state=identities.snapshot(99001L);var actor=actor(state,(String)state.get("default_user_id"),"default",1);
            actor.setTurnId("business_turn");archive(actor,"business_anchor","好的。",1);
            long now=System.currentTimeMillis()/1000;
            jdbc.update("INSERT INTO ai_person_behavior_event(account_id,user_id,generation,device_id,event_id,sequence_no,turn_id,occurred_at,intent,outcome,raw_text) VALUES(99001,?,1,?,'business_success',1,'business_turn',?,'temperature','executed','温度设为二十四度'),(99001,?,1,?,'business_failed',2,'business_turn',?,'temperature','failed','温度设为二十二度'),(99001,?,1,?,'other_agent',3,'unbound_turn',?,'temperature','executed','温度设为三十度'),(99001,?,1,?,'old',4,'business_turn',?,'temperature','executed','温度设为十度'),(99001,?,1,?,'conversation',5,'business_turn',?,'temperature','conversation','温度设为四十度')",actor.getPersonId(),actor.getDeviceId(),now,actor.getPersonId(),actor.getDeviceId(),now,actor.getPersonId(),actor.getDeviceId(),now,actor.getPersonId(),actor.getDeviceId(),now-90000,actor.getPersonId(),actor.getDeviceId(),now);
            jdbc.update("INSERT INTO ai_agent_chat_history(account_id,person_id,agent_id,mac_address,session_id,chat_type,content,turn_id,default_generation,recall_allowed,created_at) VALUES(99001,?,'agent_other',?,'other_session',1,'好的。','unbound_turn',1,TRUE,NOW())",actor.getPersonId(),actor.getDeviceId());
            String text=(String)recent.search(actor,"温度").get("text");
            assertTrue(text.contains("业务记录"));assertTrue(text.contains("已执行成功"));assertTrue(text.contains("执行失败"));
            assertTrue(text.contains("二十四度"));assertTrue(text.contains("二十二度"));assertFalse(text.contains("三十度"));assertFalse(text.contains("十度"));assertFalse(text.contains("四十度"));
            memory.override(actor,"forget","*",null);
            assertFalse((Boolean)recent.search(actor,"温度").get("reliable"));
        });
    }
}
