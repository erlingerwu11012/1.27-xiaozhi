package xiaozhi.modules.personmemory;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import xiaozhi.modules.agent.dto.AgentChatHistoryReportDTO;
import xiaozhi.modules.agent.entity.AgentEntity;
import xiaozhi.modules.useridentity.service.AccountIdentityStateService;

class RecentArchiveServiceTest {
    @Test void chineseEnglishTermsAndExcerptIncludeLongTail() {
        var terms=RecentArchiveService.terms("还记得我说的苹果和Coffee吗");
        assertTrue(terms.contains("苹果"));assertTrue(terms.contains("coffee"));
        String text="旧文字".repeat(1000)+"我喜欢苹果和coffee。";
        String result=RecentArchiveService.excerpt(text,terms,200);
        assertTrue(result.contains("苹果"));assertTrue(result.length()<205);
    }
    @Test void legacyAndUnknownRemainEnrollmentSourcesWithoutPersonAttribution() {
        var jdbc=mock(JdbcTemplate.class);var memory=mock(PersonMemoryService.class);var identities=mock(AccountIdentityStateService.class);
        var service=new RecentArchiveService(jdbc,memory,identities);
        var agent=new AgentEntity();agent.setId("agent");agent.setUserId(10L);
        var report=new AgentChatHistoryReportDTO();report.setMacAddress("device");
        assertFalse(service.validateReport(report,agent));
        var actor=new PersonTurnDTO();actor.setAccountId(10L);actor.setDeviceId("device");actor.setAgentId("agent");actor.setTurnId("turn");actor.setStatus("unknown");
        report.setIdentity(actor);
        when(jdbc.queryForObject(anyString(),eq(Integer.class),eq("device"),eq(10L),eq("agent"))).thenReturn(1);
        assertFalse(service.validateReport(report,agent));verify(memory,never()).validateArchiveActor(any());
        actor.setPersonId("dad");assertThrows(RuntimeException.class,()->service.validateReport(report,agent));
    }
    @Test void wrongAccountAndDeviceRejectedBeforeSaving() {
        var service=new RecentArchiveService(mock(JdbcTemplate.class),mock(PersonMemoryService.class),mock(AccountIdentityStateService.class));
        var agent=new AgentEntity();agent.setId("agent");agent.setUserId(10L);
        var report=new AgentChatHistoryReportDTO();report.setMacAddress("device");var actor=new PersonTurnDTO();actor.setAccountId(11L);actor.setDeviceId("device");actor.setAgentId("agent");actor.setTurnId("turn");report.setIdentity(actor);
        assertThrows(RuntimeException.class,()->service.validateReport(report,agent));
        actor.setAccountId(10L);actor.setDeviceId("other");assertThrows(RuntimeException.class,()->service.validateReport(report,agent));
    }
    @Test void realOwnerGuardCannotMintForeignAudioTicket() {
        var jdbc=mock(JdbcTemplate.class);var service=new RecentArchiveService(jdbc,mock(PersonMemoryService.class),mock(AccountIdentityStateService.class));
        when(jdbc.queryForObject(contains("a.user_id=?"),eq(Integer.class),eq("clip"),eq(10L))).thenReturn(1);
        when(jdbc.queryForObject(contains("a.user_id=?"),eq(Integer.class),eq("clip"),eq(11L))).thenReturn(0);
        assertTrue(service.audioOwned("clip",10L));assertFalse(service.audioOwned("clip",11L));
    }
}
