-- Nullable person attribution preserves anonymous enrollment audio. No backfill.
ALTER TABLE ai_agent_chat_history
 ADD COLUMN account_id BIGINT NULL,
 ADD COLUMN person_id VARCHAR(64) NULL,
 ADD COLUMN identity_status VARCHAR(24) NOT NULL DEFAULT 'legacy_unowned',
 ADD COLUMN turn_id VARCHAR(64) NULL,
 ADD COLUMN event_id VARCHAR(128) NULL,
 ADD COLUMN directory_version BIGINT NULL,
 ADD COLUMN default_generation BIGINT NULL,
 ADD COLUMN recall_allowed BOOLEAN NOT NULL DEFAULT FALSE,
 ADD UNIQUE KEY uk_chat_account_event (account_id,event_id),
 ADD KEY ix_chat_person_recent (account_id,person_id,agent_id,default_generation,recall_allowed,created_at,id),
 ADD KEY ix_chat_audio_owner (audio_id,agent_id);
