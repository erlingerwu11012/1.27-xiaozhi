import concurrent.futures
import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from core.utils.dialogue import Dialogue, Message
from core.utils.context_window import ContextWindow, estimate_request, bounded_responses, ContextLimitError, _FIELDS
from core.utils.person_identity import PersonTurn, select_dialogue


class ContextMemory200kTest(unittest.TestCase):
    def dialogue(self, rounds=12, chars=3000):
        d=Dialogue();d.put(Message('system','fixed prefix'))
        for i in range(rounds):
            d.put(Message('user',f'第{i}轮约定'+('资料'*chars)))
            d.put(Message('assistant',f'第{i}轮结果：已成功。'))
        return d

    def config(self):
        return {'context_compress':{'target_tokens':1000,'prepare_tokens':2000,'trigger_tokens':3000,'input_limit_tokens':5000}}

    def summary(self):
        return json.dumps({k:['旧约定以及最新更正、实际结果'] for k in _FIELDS},ensure_ascii=False)

    def test_defaults_and_cached_tokens_do_not_reduce_budget(self):
        w=ContextWindow(self.dialogue());self.assertEqual((w.prepare,w.trigger,w.target,w.limit),(160000,180000,50000,200000))
        m=[{'role':'user','content':'文字'*1000}]
        estimate=estimate_request(m)
        w.observe_usage(estimate,{'prompt_tokens':estimate,'prompt_tokens_details':{'cached_tokens':estimate}})
        self.assertGreaterEqual(estimate_request(m,scale=w.scale),estimate)

    def test_real_thresholds_prepare_commit_and_fifty_thousand_target(self):
        d=self.dialogue(30,3000);w=ContextWindow(d)
        llm=SimpleNamespace(response_no_stream=lambda *a,**k:self.summary())
        request=d.get_llm_dialogue_with_memory(static_system=True)
        self.assertGreaterEqual(estimate_request(request),160000)
        self.assertLess(estimate_request(request),180000)
        w.process(request,None,llm,'s');self.assertIsNotNone(w.future)
        w.future.result(timeout=10)
        d.put(Message('user','当前问题：'+('补充'*11500)))
        request=d.get_llm_dialogue_with_memory(static_system=True)
        self.assertGreaterEqual(estimate_request(request),180000)
        result=w.process(request,None,llm,'s')
        self.assertTrue(d.compact_summary)
        self.assertLessEqual(estimate_request(result),52000)
        self.assertGreaterEqual(sum(m.role=='user' for m in d.dialogue),5)

    def test_preparation_does_not_mutate_raw_history_and_twenty_thousand_guard(self):
        d=self.dialogue(30,3000);w=ContextWindow(d);before=[m.content for m in d.dialogue]
        with patch('core.utils.context_window._slots.acquire',return_value=False):
            w.process(d.get_llm_dialogue_with_memory(static_system=True),None,None)
        self.assertEqual(before,[m.content for m in d.dialogue])
        d.put(Message('user','大材料'*60000))
        with patch('core.utils.context_window._slots.acquire',return_value=False):
            view=w.process(d.get_llm_dialogue_with_memory(static_system=True),None,None)
        self.assertLessEqual(estimate_request(view),200000)
        self.assertEqual(d.dialogue[-1].content,'大材料'*60000)

    def test_all_tools_turn_context_and_arguments_counted(self):
        d=self.dialogue(2,100)
        d.dialogue[-2].prompt_context={'weather':'天晴'*300,'speaker':'爸爸'}
        messages=d.get_llm_dialogue_with_memory(static_system=True)
        tools=[{'type':'function','function':{'name':'a','description':'介绍'*1000}}]
        self.assertGreater(estimate_request(messages,tools),estimate_request(messages))
        self.assertEqual(sum(m.get('content')=='fixed prefix' for m in messages),1)

    def test_more_than_fifty_messages_and_long_outputs_preserved(self):
        d=self.dialogue(40,10);d.put(Message('assistant','长结果'*2000));before=[m.content for m in d.dialogue]
        w=ContextWindow(d);w.process(d.get_llm_dialogue_with_memory(static_system=True),None,None)
        self.assertEqual(before,[m.content for m in d.dialogue])

    def test_complete_batches_include_old_summary_and_long_tail(self):
        d=self.dialogue(6,22000);d.compact_summary='上一份约定：星期五提醒'
        w=ContextWindow(d);prompts=[]
        llm=SimpleNamespace(response_no_stream=lambda s,u,**kw:(prompts.append((s,u,kw)) or self.summary()))
        result=w._summarize(d.dialogue[1:5],0,d.compact_summary,llm,'account-session')
        self.assertIn('上一份约定',prompts[0][1])
        fragments=[f['text'] for _,u,_ in prompts for f in json.loads(u)['complete_source_fragments']]
        self.assertEqual(''.join(fragments),''.join(json.dumps(w._serialized([m])[0],ensure_ascii=False) for m in d.dialogue[1:5]))
        self.assertTrue(all(estimate_request([{'role':'system','content':s},{'role':'user','content':u}])<=24000 for s,u,_ in prompts))
        self.assertTrue(all(p[2]['session_id']=='account-session' for p in prompts))
        self.assertLessEqual(len(result.text),6000)

    def test_invalid_summary_cannot_commit(self):
        for raw in ('not JSON','{}',json.dumps({k:['x'*6001] for k in _FIELDS}),json.dumps({k:[] for k in _FIELDS})):
            d=self.dialogue(8,100);w=ContextWindow(d,self.config());before=list(d.dialogue)
            with self.assertRaises((ValueError,json.JSONDecodeError)):
                w._summarize(d.dialogue[1:3],0,'',SimpleNamespace(response_no_stream=lambda *a,**k:raw),'s')
            self.assertEqual(d.dialogue,before)

    def candidate(self,d,w):
        source=d.dialogue[1:-8]
        result=w._summarize(source,w.version,d.compact_summary,SimpleNamespace(response_no_stream=lambda *a,**k:self.summary()),'s')
        future=concurrent.futures.Future();future.set_result(result);w.future=future

    def test_commit_atomic_and_recent_four_rounds_retained(self):
        d=self.dialogue(9,400);w=ContextWindow(d,self.config());self.candidate(d,w)
        with patch('core.utils.context_window._slots.acquire',return_value=False):
            w.process(d.get_llm_dialogue_with_memory(static_system=True),None,None)
        self.assertTrue(d.compact_summary)
        self.assertEqual(sum(m.role=='user' for m in d.dialogue),4)

    def test_correction_and_mutated_source_reject_late_candidate(self):
        for invalidate in (True,False):
            d=self.dialogue(9,400);w=ContextWindow(d,self.config());self.candidate(d,w)
            if invalidate:w.invalidate()
            else:d.dialogue[1].content='更正的新信息'
            with patch('core.utils.context_window._slots.acquire',return_value=False):w.process(d.get_llm_dialogue_with_memory(static_system=True),None,None)
            self.assertFalse(d.compact_summary);self.assertEqual(sum(m.role=='user' for m in d.dialogue),9)

    def test_protection_is_view_only_and_tool_pairs_intact(self):
        d=self.dialogue(9,4000);d.put(Message('assistant',tool_calls=[{'id':'call-a','function':{'name':'volume','arguments':'{}'},'type':'function'}]))
        d.put(Message('tool','操作成功'+('x'*120000),tool_call_id='call-a'))
        w=ContextWindow(d,self.config());before=[m.content for m in d.dialogue]
        view=w.protect(d.get_llm_dialogue_with_memory(static_system=True),None,5000)
        self.assertLessEqual(estimate_request(view),5000)
        self.assertEqual(before,[m.content for m in d.dialogue])
        self.assertEqual(sum(bool(m.get('tool_calls')) for m in view),1)
        self.assertEqual(sum(m['role']=='tool' for m in view),1)

    def test_context_retry_once_no_repeated_tool(self):
        class Provider:
            calls=0
            def response_with_functions(self,*a,**k):
                self.calls+=1
                if self.calls==1:raise ContextLimitError('input too long')
                yield ('已执行的结果',None)
        p=Provider();w=ContextWindow(self.dialogue())
        result=list(bounded_responses(p,'s',[{'role':'user','content':'hi'}],[],w))
        self.assertEqual(p.calls,2);self.assertEqual(len(result),1)

    def test_no_retry_after_partial_output(self):
        class Provider:
            calls=0
            def response(self,*a,**k):
                self.calls+=1;yield 'already spoken';raise ContextLimitError('too long')
        p=Provider();w=ContextWindow(self.dialogue())
        with self.assertRaises(ContextLimitError):list(bounded_responses(p,'s',[{'role':'user','content':'hi'}],None,w))
        self.assertEqual(p.calls,1)

    def actor(self,person='',status='unknown',version=2):
        return PersonTurn('10',person,0,version,'personal',status,'turn-'+str(version),'device','agent',1)

    def test_unknown_continuous_chat_and_transition_clear(self):
        conn=SimpleNamespace(config={},prompt='prefix',session_id='session')
        select_dialogue(conn,self.actor());first=conn.dialogue;first.put(Message('user','故事'))
        select_dialogue(conn,self.actor());self.assertIs(first,conn.dialogue)
        select_dialogue(conn,self.actor('dad','matched'));self.assertIsNot(first,conn.dialogue)
        select_dialogue(conn,self.actor());self.assertNotIn('故事',[m.content for m in conn.dialogue.dialogue])
        select_dialogue(conn,self.actor(version=3));self.assertEqual(len(conn._person_dialogues),2)

    def test_unknown_local_and_cloud_never_called(self):
        import asyncio
        from core.utils.person_identity import activate,deactivate
        from core.utils.recent_memory import search
        conn=SimpleNamespace();token=activate(conn,self.actor())
        try:self.assertEqual(asyncio.run(search(conn,'爸爸喜欢什么'))['status'],'identity_unknown')
        finally:deactivate(token)

    def test_late_connection_close_cannot_restore_corrected_summary(self):
        import asyncio,tempfile
        from pathlib import Path
        from unittest.mock import MagicMock
        from core.utils.person_material_outbox import MaterialOutbox
        from core.utils import person_short_memory as store
        actor=self.actor('dad','matched')
        with tempfile.TemporaryDirectory() as folder, patch.object(store,'material_outbox',MaterialOutbox(str(Path(folder)/'isolated.sqlite'))):
            self.assertEqual(store.revision(actor),0)
            store.invalidate(actor)
            conn=SimpleNamespace(memory=SimpleNamespace(llm=MagicMock()))
            asyncio.run(store.save(conn,actor,[Message('user','旧咖啡偏好')],'',source_revision=0))
            conn.memory.llm.response_no_stream.assert_not_called()
            self.assertEqual(store.load(actor),'')

if __name__=='__main__':unittest.main()
